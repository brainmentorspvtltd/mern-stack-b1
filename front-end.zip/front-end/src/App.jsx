import React from "react";
import Register from "./modules/user/pages/Register";
function App() {
  return (
    <Register />
    // <div>
    //   <h1>Hello React JS</h1>
    //   <h2>Brain Mentors</h2>
    // </div>
  );
  // return React.createElement(
  //   "div",
  //   null,
  //   React.createElement("h1", null, "Hello React JS"),
  //   React.createElement("h2", null, "Brain Mentors")
  // );
}
export default App;
