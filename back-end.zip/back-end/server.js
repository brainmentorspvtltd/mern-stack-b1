import express from 'express';
import { userRoutes } from './src/api/v1/routes/user-routes.js';
import { error404 } from './src/utils/middlewares/404.js';
const app = express();
app.use(express.json());
app.use('/', userRoutes);
//app.use(middleware)
// 404 middleware
app.use(error404);

const server = app.listen(1234, err=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running ', server.address().port);
    }
})