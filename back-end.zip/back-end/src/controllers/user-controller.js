
export const home = (request, response)=>{
    response.send('<h1>URL Shortener Project </h1>');
}
export const login = (request, response)=>{
    response.send('<h1> Login </h1>');
}
export const register = (request, response)=>{
    const userInfo = request.body;
    console.log('User info ', userInfo);
    response.send('<h1> Register </h1>');
}