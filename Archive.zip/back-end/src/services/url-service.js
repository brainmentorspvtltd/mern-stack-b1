import { UrlModel } from "../models/url-schema.js"

// User Service - CRUD
export const addURL = async (urlObject)=>{
    try{
    const doc = await UrlModel.create(urlObject);
    return doc;
    }
    catch(err){
        throw err;
    }
}