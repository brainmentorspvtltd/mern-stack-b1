export const error404 = (request, response, next)=>{
    response.send("<h2>OOPS Something went Wrong...");
}