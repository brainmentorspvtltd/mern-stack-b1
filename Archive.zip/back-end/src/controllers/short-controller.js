import { nanoid } from "nanoid";
import { addURL } from "../services/url-service.js";

export const urlShort = async (request, response)=>{
    const bigUrl = request.body.bigurl;
    console.log('Big URL ', bigUrl);
    try{
    const num = nanoid(6);
    const doc = await addURL({email:'amit@yahoo.com',shortid: num, bigurl:bigUrl });
    if(doc && doc._id){
        response.json({shorturl:'http://localhost:1234/'+num});
    }
    else{
        response.json({error: 'Something went Wrong'})
    }
    
    }
    catch(err){
        console.log('Error in Short URL ', err);
        response.json({error: 'Something went Wrong', err});
    }

}