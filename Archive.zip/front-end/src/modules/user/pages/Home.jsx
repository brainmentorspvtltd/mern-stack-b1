export const Home = () => {
  return <h1>Url Shortener App</h1>;
};
